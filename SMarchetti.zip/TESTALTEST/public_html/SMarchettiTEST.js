/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function printMS() {

    let nome = document.getElementById("ins_nome").value;
    let date = new Date();
    let ris = "Oggi è il " + date + " ciao " + nome + ", buona giornata!";

    document.getElementById("risms").innerHTML = ris;

}


function switchB() {

    let nome1 = document.getElementById("ins_nome1").value;
    let nome2 = document.getElementById("ins_nome2").value;
    let nome3 = document.getElementById("ins_nome3").value;

    document.getElementById("ins_nome1").value = nome3;
    document.getElementById("ins_nome2").value = nome1;
    document.getElementById("ins_nome3").value = nome2;

}

var ar_acquisto = [];
var ar_costo = [];
var tot_pagamento = [];

function addAcquisto() {
    ar_acquisto.push(document.getElementById("in_acquisto").value);
    ar_costo.push(document.getElementById("in_costo").value);
    
    let text= "";
    let tot = 0;
    let media = 0;
    
    for (i = 0; i < ar_acquisto.length; i++) {
        
        text +=ar_acquisto[i] + "-" + ar_costo[i] + "<br>"; 
        tot += ar_costo[i]*1;
        
        
    }
    document.getElementById("div_acquisto").innerHTML = text;
    document.getElementById("div_tot").innerHTMl = totale;
    media += totale / ar_acquisto.length;
    doument.getElementById("div_media").innerHTML = media;
    document.getElementById("div_max").innerHTML = max;
    max = Math.max.apply(null, ar_costo);
    document.getElementById("div_min").innerHTML = min;
    min = Math.min.apply(null, ar_costo);
    
}